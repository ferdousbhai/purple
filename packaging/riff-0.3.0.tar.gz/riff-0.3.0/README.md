# Riff

Riff is a desktop app for making music with AI.

You type a plain-English music idea, such as "make a slow lo-fi drum loop with warm chords." Riff asks Gemini to write a Strudel music pattern, puts that pattern in the editor, and plays it through your computer speakers.

The app has two main areas:

- The left side is the music code editor and play controls.
- The right side is the chat where you ask for music or changes.

## What You Need

- A Linux computer (Arch, Omarchy, Ubuntu, Fedora — anything with a system webview). macOS and Windows build from source too, but the packaging below is Linux-first.
- An internet connection.
- A Google Gemini API key.

## Install On Arch Or Omarchy

Riff builds into a single native binary and installs like any other Arch package.

```bash
git clone https://github.com/ferdousbhai/riff.git
cd riff/packaging
makepkg -si
```

That installs `/usr/bin/riff`, a desktop entry, and the app icons. Open the
Omarchy launcher with `Super + Space` and search for `Riff`, or run `riff` in a
terminal. Updates come with `omarchy-update` once the package is in the AUR.

Riff needs these runtime packages, which `makepkg` installs for you:
`webkit2gtk-4.1`, `gtk3`, `gst-plugins-base`, `gst-plugins-good`, `libsecret`.

## Install Without A Package Manager

From a checkout, this builds Riff and installs it for the current user only:

```bash
./scripts/install-user.sh
```

It puts the binary in `~/.local/bin/riff`, adds the desktop entry and icons
under `~/.local/share`, and refreshes the Omarchy launcher when it is present.

## Build From Source For Development

Riff needs [Rust](https://rustup.rs) (1.85 or newer), Node.js 22, and pnpm 10.

```bash
pnpm install
pnpm run dev
```

`pnpm run dev` starts Vite and the Rust shell together, with hot reload for the
interface. A desktop window named Riff opens. Close the window to stop it.

On Debian or Ubuntu, install the webview development packages first:

```bash
sudo apt install libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev
```

## Add Your Google Gemini API Key

Riff needs a Google Gemini API key so it can ask Gemini to generate music patterns.

Create an API key in Google AI Studio. In Riff, click `KEY`, paste the API key,
and save it. Riff stores it in your system keyring (GNOME Keyring, KWallet, or
whatever provides the Secret Service on your machine), not in a plain file.

If you already export `GEMINI_API_KEY` in your shell, Riff uses that.

If you try to send a prompt before adding a key, Riff opens the key box
automatically and keeps your prompt in the chat input.

## Make Some Music

In the chat box on the right, type a request like:

```text
Make a mellow lo-fi beat with soft drums and jazzy chords.
```

Press `Enter`.

Gemini will reply with a Strudel pattern. Riff will place the pattern in the editor on the left. Use the play controls, or press `Ctrl+Enter`, to hear it.

You can ask for changes in normal language:

```text
Make it faster and add a bassline.
```

```text
Make the drums simpler and the chords darker.
```

## Command Line Usage

With no arguments, Riff opens a random built-in musical recipe. It waits for
your click before playing, because the webview only starts audio after a user
action.

```bash
# Direct Strudel live-coding pattern (click START AUDIO after launch)
riff 's("bd hh sd hh")'
riff 'note("c3 e3 g3 b3").s("sawtooth").lpf(800).room(0.5)'

# Built-in presets
riff lofi
riff techno
riff ambient
riff dnb
riff chiptune
riff basic

# Natural language prompt (generates the pattern, then asks you to start audio)
riff "make a dark cyberpunk acid techno groove"

# Explicit flags
riff --preset basic
riff --code 's("bd*4")'
riff --prompt "make a sparse ambient pattern"
```

Riff runs as a single instance. Running `riff lofi` while Riff is already open
focuses the existing window and loads that pattern instead of starting a second
copy.

## Keyboard Shortcuts

- `Enter`: send a chat message.
- `Ctrl+Enter`: play or re-run the pattern in the editor.
- `Ctrl+.`: stop playback.
- `Escape`: stop Gemini while it is still writing a response.

## Troubleshooting

### "Invalid API key"

Click `KEY`, clear the saved app key, paste a valid Google Gemini API key, and save
it again.

### The app opens, but no sound plays

- Make sure your computer volume is up.
- Make sure the correct speakers or headphones are selected.
- For a pattern loaded from the command line, click `START AUDIO`. Webviews require a user action before audio can start.
- Try a simple prompt such as `make a basic drum beat`.

### Linux: the window is blank or transparent

WebKitGTK's DMABUF renderer draws nothing on several Mesa drivers, so Riff turns
it off by default. If your machine handles it well and you want the accelerated
path, start Riff with:

```bash
RIFF_GPU=1 riff
```

If a blank window persists, add `WEBKIT_DISABLE_COMPOSITING_MODE=1` to disable
more of the accelerated path.

### The app says it was rate limited

The Gemini API is temporarily refusing more requests. Wait a minute and try again.

### The app says it cannot connect

Check your internet connection, then restart Riff.

## Developer Commands

```bash
pnpm run dev        # Vite + the Rust shell, with hot reload
pnpm run dev:web    # Vite alone, for browser-only interface work
pnpm run build      # Release binary at src-tauri/target/release/riff
pnpm run test       # Interface and shared-logic tests
pnpm run test:rust  # Shell tests
pnpm run typecheck  # TypeScript check
pnpm run check      # Everything above plus a production web build
```

The logs from a running app are in `~/.local/share/dev.ferdous.riff/logs/`.

## Technology Used

- Tauri 2 for the native window and the Rust shell.
- React and Tailwind CSS for the interface.
- CodeMirror for the code editor.
- Strudel for webview-based music playback.
- The Gemini Interactions API for music pattern generation.
